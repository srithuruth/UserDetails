package com.example.kathishan.userdetails;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

    public class Constant {

          public static final String KEY_2 = "value2";

    }

